public class CountryCapital {

    String country;
    String capital;

    public CountryCapital(String country, String capital){
        this.capital =capital;
        this.country = country;

    }
    public String getCountry(){
        return country;
    }

    public String getCapital(){
        return capital;
    }

}
