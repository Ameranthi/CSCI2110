import java.util.Scanner;

public class julia {
    public static void main (String[]args){

        String julia = "fuckbitchesgetmoney69";
        if(julia.matches("[a-z]+")){
            System.out.println("Pass");
        }else{
            System.out.println("Fail");
        }
    }
}
